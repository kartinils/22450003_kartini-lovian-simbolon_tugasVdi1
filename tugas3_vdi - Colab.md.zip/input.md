9/29/24, 12:26 AM tugas3_vdi.ipynb - Colab

> 1import numpy as np 2import pandas as pd 3
>
> 4df1 = pd.read_csv('diabetes_null.csv', na_values = \['#NAME'\]) 5data
> = pd.DataFrame(df1)
>
> <img src="./asbnp1gz.png"
> style="width:0.22222in;height:0.22222in" /><img src="./3zanenz1.png"
> style="width:0.22222in;height:0.22222in" />6data
>
> **Pregnancies**
>
> **0** 6
>
> **1** 1
>
> **2** 8
>
> **3** 1
>
> **4** 0
>
> **...** ...
>
> **763** 10
>
> **764** 2
>
> **765** 5
>
> **766** 1
>
> **767** 1

**Glucose**

> 148.0
>
> 85.0
>
> 183.0
>
> 89.0
>
> 137.0
>
> ...
>
> 11.0
>
> 122.0
>
> 121.0
>
> 126.0
>
> 93.0

**BloodPressure**

> 72.0
>
> 66.0
>
> 64.0
>
> 66.0
>
> 4.0
>
> ...
>
> 76.0
>
> 7.0
>
> 72.0
>
> 6.0
>
> 7.0

**SkinThickness**

> 35.0
>
> 29.0
>
> NaN
>
> 23.0
>
> 35.0
>
> ...
>
> 48.0
>
> 27.0
>
> 23.0
>
> NaN
>
> 31.0

**Insulin** **BMI**

> NaN 33.6
>
> NaN 26.6
>
> NaN 23.3
>
> 94.0 28.1
>
> 168.0 43.1
>
> ... ...
>
> 18.0 32.9
>
> NaN 36.8
>
> 112.0 26.2
>
> NaN 3.1
>
> NaN 3.4

**DiabetesPedigreeFunction**

> 0.627
>
> 0.351
>
> 0.672
>
> 0.167
>
> 2.288
>
> ...
>
> 0.171
>
> 0.340
>
> 0.245
>
> 0.349
>
> 0.315

**Age** **Outcome**

> 5 1
>
> 31 0
>
> 32 1
>
> 21 0
>
> 33 1
>
> ... ...
>
> 63 0
>
> 27 0
>
> 3 0
>
> 47 1
>
> 23 0
>
> 768 rows × 9 columns
>
> Next steps: Generate code with data  View recommended plots New
> interactive sheet
>
> 1import matplotlib.pyplot as plt 2import seaborn as sns
>
> 3
>
> 4# Set the style for the plots 5sns.set(style="whitegrid")
>
> 6
>
> 7# Set the figure size for better visualization
> 8plt.figure(figsize=(10, 6))
>
> 9
>
> 10# Create a boxplot to compare Glucose levels for patients with and
> without diabetes 11plt.subplot(1, 2, 1)
>
> 12boxplot_glucose = sns.boxplot(x='Outcome', y='Glucose', data=data,
> palette='coolwarm', hue='Outcome', legend=False)
> 13boxplot_glucose.set_title('Glucose Levels by Diabetes Outcome',
> fontsize=14) 14boxplot_glucose.set_xlabel('Diabetes Outcome (0 = No, 1
> = Yes)', fontsize=12) 15boxplot_glucose.set_ylabel('Glucose Level',
> fontsize=12)
>
> 16
>
> 17# Create a boxplot to compare BMI for patients with and without
> diabetes 18plt.subplot(1, 2, 2)
>
> 19boxplot_bmi = sns.boxplot(x='Outcome', y='BMI', data=data,
> palette='coolwarm', hue='Outcome', legend=False)
> 20boxplot_bmi.set_title('BMI by Diabetes Outcome', fontsize=14)
>
> 21boxplot_bmi.set_xlabel('Diabetes Outcome (0 = No, 1 = Yes)',
> fontsize=12) 22boxplot_bmi.set_ylabel('BMI', fontsize=12)
>
> 23
>
> 24# Adjust layout to prevent overlap 25plt.tight_layout()
>
> 26
>
> 27# Show the plot 28plt.show()
>
> 29 30

https://colab.research.google.com/drive/17-J5nmzKb9nRuN4Szpsrlg6obQ5d-uC1#scrollTo=x5pymksKkoNn&uniqifier=1&printMode=true
1/2

9/29/24, 12:26 AM tugas3_vdi.ipynb -
Colab<img src="./e0xdwp20.png"
style="width:6.83333in;height:4.04861in" />

> Tujuan: Monitor Risiko Diabetes: Tujuan ini paling relevan, karena
> data tersebut berisi berbagai variabel yang mempengaruhi risiko
> diabetes, seperti glukosa, tekanan darah, dan BMI. Memantau
> faktor-faktor ini secara berkala membantu mencegah atau mengelola
> diabetes.
>
> Fungsi: Exploratory: Fungsi eksplorasi paling sesuai untuk menemukan
> pola dan hubungan antara variabel-variabel dalam data. Dengan fungsi
> ini, pengguna dapat memahami bagaimana setiap faktor mempengaruhi
> risiko diabetes dan menemukan insight baru.
>
> Tone: Scienti c and Clinical: Tone ilmiah dan klinis sangat tepat,
> karena data ini terutama akan digunakan oleh profesional kesehatan
> atau peneliti. Visualisasi yang akurat dan berbasis data sangat
> penting untuk memberikan informasi yang dapat diandalkan.
>
> User: One-to-One Exchange with Manager: User ini mencakup dokter atau
> manajer kesehatan yang bekerja secara langsung dengan pasien. Mereka
> membutuhkan visualisasi yang informatif dan mendalam untuk
> mendiskusikan kondisi pasien dan menentukan tindakan medis selanjutnya

https://colab.research.google.com/drive/17-J5nmzKb9nRuN4Szpsrlg6obQ5d-uC1#scrollTo=x5pymksKkoNn&uniqifier=1&printMode=true
2/2
